import React, { useState, useEffect } from 'react';

export default function Dashboard() {
    const [data, setData] = useState(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        // Fetch dashboard data
        const fetchData = async () => {
            try {
                // Replace with your API endpoint
                const response = await fetch('/api/dashboard');
                const result = await response.json();
                setData(result);
            } catch (error) {
                console.error('Error fetching dashboard data:', error);
            } finally {
                setLoading(false);
            }
        };

        fetchData();
    }, []);

    if (loading) {
        return <div className="p-8">Loading...</div>;
    }

    return (
        <div className="p-8">
            <h1 className="text-3xl font-bold mb-6">Dashboard</h1>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                {/* Add dashboard cards/widgets here */}
                <div className="bg-white p-6 rounded-lg shadow">
                    <h2 className="text-lg font-semibold">Widget</h2>
                    <p className="text-gray-600">Your content here</p>
                </div>
            </div>
        </div>
    );
}