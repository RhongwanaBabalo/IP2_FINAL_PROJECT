const bcrypt = require('bcryptjs');
const readline = require('readline');

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

console.log('\n🔐 Admin Password Generator\n');
console.log('This tool will generate a bcrypt hash for your admin password.\n');

rl.question('Enter your desired admin password: ', async (password) => {
    if (!password || password.length < 6) {
        console.log('\n❌ Password must be at least 6 characters long!\n');
        rl.close();
        return;
    }
    
    console.log('\n⏳ Generating hash...\n');
    
    // Generate bcrypt hash with 10 salt rounds
    const hash = await bcrypt.hash(password, 10);
    
    console.log('✅ Hash generated successfully!\n');
    console.log('=' .repeat(60));
    console.log('Your password:', password);
    console.log('Your hash:', hash);
    console.log('=' .repeat(60));
    console.log('\n📝 Copy this SQL command to update your admin user:\n');
    console.log(`UPDATE users SET password = '${hash}' WHERE email = 'admin@civicconnect.com';\n`);
    
    rl.close();
});