require('dotenv').config();
const express = require('express');
const path = require('path');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const mysql = require('mysql2');
const QRCode = require('qrcode');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const multer = require('multer');
const fs = require('fs');
const sharp = require('sharp'); // ADDED FOR IMAGE PROCESSING

const app = express();
const PORT = process.env.PORT || 3000;

// ========== DATABASE CONNECTION ==========
const db = mysql.createConnection({
    host: process.env.DB_HOST || 'localhost',
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || '',
    database: process.env.DB_NAME || 'civicconnect',
    port: 3306
});

db.connect((err) => {
    if (err) {
        console.error('❌ MySQL connection error:', err.message);
        console.log('💡 Make sure XAMPP MySQL is running!');
    } else {
        console.log('✅ MySQL database connected');
        initDatabase();
    }
});

// ========== INITIALIZE DATABASE TABLES ==========
function initDatabase() {
    const createUsersTable = `
        CREATE TABLE IF NOT EXISTS users (
            id INT PRIMARY KEY AUTO_INCREMENT,
            full_name VARCHAR(255) NOT NULL,
            email VARCHAR(255) UNIQUE NOT NULL,
            password VARCHAR(255) NOT NULL,
            phone VARCHAR(50),
            address TEXT,
            account_type ENUM('citizen', 'municipal', 'admin') DEFAULT 'citizen',
            role ENUM('citizen', 'municipal', 'admin') DEFAULT 'citizen',
            is_active BOOLEAN DEFAULT TRUE,
            points INT DEFAULT 0,
            badges TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )
    `;
    
    db.query(createUsersTable, async (err) => {
        if (err) {
            console.error('Users table error:', err);
        } else {
            console.log('✅ Users table ready');
            
            db.query('SELECT id FROM users WHERE email = ?', ['admin@civicconnect.com'], async (err, results) => {
                if (err) return;
                if (results.length === 0) {
                    const hashedPassword = await bcrypt.hash('admin123', 10);
                    db.query(
                        `INSERT INTO users (full_name, email, password, account_type, role, points) 
                         VALUES (?, ?, ?, ?, ?, ?)`,
                        ['System Admin', 'admin@civicconnect.com', hashedPassword, 'admin', 'admin', 0]
                    );
                    console.log('✅ Default admin created (email: admin@civicconnect.com, password: admin123)');
                }
            });
        }
    });
    
    const createReportsTable = `
        CREATE TABLE IF NOT EXISTS reports (
            id INT PRIMARY KEY AUTO_INCREMENT,
            reference VARCHAR(50) UNIQUE NOT NULL,
            user_id INT NOT NULL,
            citizen_name VARCHAR(255) NOT NULL,
            email VARCHAR(255),
            phone VARCHAR(50),
            title VARCHAR(255) NOT NULL,
            description TEXT NOT NULL,
            category VARCHAR(50) NOT NULL,
            priority VARCHAR(20) DEFAULT 'medium',
            status ENUM('pending', 'in_progress', 'resolved', 'rejected') DEFAULT 'pending',
            location_address TEXT,
            location_lat DECIMAL(10, 8),
            location_lng DECIMAL(11, 8),
            image_path VARCHAR(255),
            qr_code TEXT,
            is_anonymous BOOLEAN DEFAULT FALSE,
            urgency_score INT DEFAULT 1,
            views INT DEFAULT 0,
            admin_notes TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        )
    `;
    
    db.query(createReportsTable, (err) => {
        if (err) console.error('Reports table error:', err);
        else console.log('✅ Reports table ready');
    });
    
    const createStatusHistoryTable = `
        CREATE TABLE IF NOT EXISTS status_history (
            id INT PRIMARY KEY AUTO_INCREMENT,
            report_id INT NOT NULL,
            old_status VARCHAR(50),
            new_status VARCHAR(50) NOT NULL,
            changed_by VARCHAR(255),
            changed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (report_id) REFERENCES reports(id) ON DELETE CASCADE
        )
    `;
    
    db.query(createStatusHistoryTable, (err) => {
        if (err) console.error('Status history table error:', err);
        else console.log('✅ Status history table ready');
    });
}

// ========== HELPER FUNCTIONS ==========
function autoCategorize(description, title) {
    const text = (description + ' ' + title).toLowerCase();
    
    const categories = {
        'roads': ['pothole', 'road', 'street', 'speed bump', 'traffic', 'sidewalk', 'pavement', 'bridge', 'sign'],
        'water': ['water', 'leak', 'pipe', 'flood', 'drainage', 'tap', 'hydrant', 'sewage'],
        'electricity': ['light', 'streetlight', 'power', 'electricity', 'cable', 'transformer', 'outage', 'flicker'],
        'sanitation': ['sewer', 'rubbish', 'garbage', 'dump', 'waste', 'trash', 'recycling', 'litter'],
        'safety': ['crime', 'theft', 'safety', 'dangerous', 'security', 'violence', 'assault', 'vandalism']
    };
    
    for (const [category, keywords] of Object.entries(categories)) {
        if (keywords.some(keyword => text.includes(keyword))) {
            return category;
        }
    }
    return 'other';
}

function autoSetPriority(description, title, category) {
    const text = (description + ' ' + title).toLowerCase();
    
    const emergency = ['emergency', 'urgent', 'immediate', 'dangerous', 'life threatening', 'collapse', 'injury', 'accident', 'fire'];
    const high = ['severe', 'major', 'critical', 'hazardous', 'flooding', 'blocked', 'broken'];
    
    if (emergency.some(word => text.includes(word))) return 'emergency';
    if (high.some(word => text.includes(word))) return 'high';
    if (category === 'safety') return 'high';
    return 'medium';
}

function generateReference() {
    const year = new Date().getFullYear();
    const random = Math.floor(Math.random() * 10000);
    return `CRC-${year}-${random}`;
}

async function generateQRCode(reference) {
    try {
        const trackingUrl = `http://localhost:${PORT}/track/${reference}`;
        const qrCodeDataURL = await QRCode.toDataURL(trackingUrl);
        return qrCodeDataURL;
    } catch (error) {
        console.error('QR Generation error:', error);
        return null;
    }
}

// ========== NLP ENHANCEMENTS ==========

// 1. Enhanced Categorization with Synonyms and Context
function advancedCategorize(text) {
    const lowerText = text.toLowerCase();
    
    const categories = {
        'roads': {
            keywords: ['pothole', 'road', 'street', 'speed bump', 'traffic', 'sidewalk', 
                       'pavement', 'bridge', 'sign', 'asphalt', 'tarmac', 'highway', 
                       'lane', 'intersection', 'crosswalk', 'curb'],
            confidence: 0
        },
        'water': {
            keywords: ['water', 'leak', 'pipe', 'flood', 'drainage', 'tap', 'hydrant', 
                       'sewage', 'drip', 'flow', 'burst', 'drain', 'plumbing', 'wet'],
            confidence: 0
        },
        'electricity': {
            keywords: ['light', 'streetlight', 'power', 'electricity', 'cable', 
                       'transformer', 'outage', 'flicker', 'wire', 'socket', 'pole',
                       'breaker', 'fuse', 'voltage'],
            confidence: 0
        },
        'sanitation': {
            keywords: ['sewer', 'rubbish', 'garbage', 'dump', 'waste', 'trash', 
                       'recycling', 'litter', 'bin', 'collection', 'smell', 'rotten',
                       'overflow', 'spillage', 'contamination'],
            confidence: 0
        },
        'safety': {
            keywords: ['crime', 'theft', 'safety', 'dangerous', 'security', 'violence', 
                       'assault', 'vandalism', 'robbery', 'burglary', 'harassment',
                       'unsafe', 'threat', 'suspicious'],
            confidence: 0
        }
    };
    
    for (const [category, data] of Object.entries(categories)) {
        let matches = 0;
        for (const keyword of data.keywords) {
            if (lowerText.includes(keyword)) {
                matches++;
            }
        }
        data.confidence = matches / data.keywords.length;
    }
    
    let bestCategory = 'other';
    let highestConfidence = 0;
    
    for (const [category, data] of Object.entries(categories)) {
        if (data.confidence > highestConfidence && data.confidence > 0.1) {
            highestConfidence = data.confidence;
            bestCategory = category;
        }
    }
    
    return { category: bestCategory, confidence: highestConfidence };
}

// 2. Sentiment Analysis - Detect urgency level from text
function analyzeSentiment(text) {
    const lowerText = text.toLowerCase();
    
    const urgencyPhrases = {
        'extreme': ['emergency', 'urgent', 'immediate', 'critical', 'life threatening', 
                    'dangerous', 'desperate', 'unbearable', 'intolerable'],
        'high': ['serious', 'severe', 'major', 'significant', 'dangerous', 'hazardous',
                 'urgent action', 'needs immediate', 'bad', 'terrible'],
        'medium': ['concern', 'issue', 'problem', 'difficult', 'inconvenient', 
                   'needs attention', 'please help', 'request'],
        'low': ['minor', 'small', 'slight', 'cosmetic', 'aesthetic', 'non urgent']
    };
    
    let urgencyScore = 1;
    let matchedPhrases = [];
    
    for (const [level, phrases] of Object.entries(urgencyPhrases)) {
        for (const phrase of phrases) {
            if (lowerText.includes(phrase)) {
                matchedPhrases.push(phrase);
                if (level === 'extreme') urgencyScore = 4;
                else if (level === 'high' && urgencyScore < 3) urgencyScore = 3;
                else if (level === 'medium' && urgencyScore < 2) urgencyScore = 2;
            }
        }
    }
    
    const negativeWords = ['frustrated', 'angry', 'disappointed', 'fed up', 'tired'];
    for (const word of negativeWords) {
        if (lowerText.includes(word) && urgencyScore < 3) {
            urgencyScore = 3;
        }
    }
    
    return {
        urgencyScore: urgencyScore,
        matchedPhrases: matchedPhrases,
        sentiment: urgencyScore >= 3 ? 'urgent' : urgencyScore >= 2 ? 'concerned' : 'informative'
    };
}

// 3. Generate Report Summary (Text Summarization)
function generateSummary(text, maxLength = 100) {
    if (!text || text.length <= maxLength) return text;
    
    const sentences = text.match(/[^.!?]+[.!?]+/g) || [text];
    let summary = '';
    const importantWords = ['urgent', 'important', 'critical', 'dangerous', 'water', 'road', 'light', 'crime'];
    
    if (sentences.length > 0) {
        summary = sentences[0];
    }
    
    for (let i = 1; i < sentences.length && summary.length < maxLength; i++) {
        const sentence = sentences[i];
        if (importantWords.some(word => sentence.toLowerCase().includes(word))) {
            summary += ' ' + sentence;
        }
    }
    
    return summary.substring(0, maxLength) + (summary.length > maxLength ? '...' : '');
}

// 4. Find Similar Reports - Prevent duplicates
function findSimilarReports(newReport, existingReports, threshold = 0.3) {
    const similar = [];
    const newWords = newReport.toLowerCase().split(/\s+/);
    const newSet = new Set(newWords);
    
    for (const existing of existingReports) {
        const existingWords = existing.toLowerCase().split(/\s+/);
        const existingSet = new Set(existingWords);
        
        const intersection = new Set([...newSet].filter(x => existingSet.has(x)));
        const union = new Set([...newSet, ...existingSet]);
        const similarity = intersection.size / union.size;
        
        if (similarity > threshold) {
            similar.push({
                similarity: similarity,
                text: existing
            });
        }
    }
    
    return similar.sort((a, b) => b.similarity - a.similarity);
}

function enhancedAutoCategorize(description, title) {
    const text = (description + ' ' + title);
    return advancedCategorize(text);
}

// ========== IMAGE PROCESSING ENHANCEMENTS ==========

// 1. Image Compression and Processing
async function processImage(inputPath, outputPath, options = {}) {
    try {
        const {
            width = 800,
            height = 800,
            quality = 80,
            fit = 'inside'
        } = options;
        
        // Read image metadata
        const metadata = await sharp(inputPath).metadata();
        const imageInfo = {
            width: metadata.width,
            height: metadata.height,
            format: metadata.format,
            size: fs.statSync(inputPath).size
        };
        
        // Process image
        await sharp(inputPath)
            .resize(width, height, { fit: fit })
            .jpeg({ quality: quality })
            .toFile(outputPath);
        
        // Get processed image info
        const processedMetadata = await sharp(outputPath).metadata();
        const processedSize = fs.statSync(outputPath).size;
        
        // Calculate compression ratio
        const compressionRatio = ((imageInfo.size - processedSize) / imageInfo.size) * 100;
        
        // Generate thumbnail
        const thumbPath = outputPath.replace(/\.[^.]+$/, '_thumb.jpg');
        await sharp(inputPath)
            .resize(150, 150, { fit: 'cover' })
            .jpeg({ quality: 60 })
            .toFile(thumbPath);
        
        return {
            original: imageInfo,
            processed: {
                width: processedMetadata.width,
                height: processedMetadata.height,
                size: processedSize,
                format: processedMetadata.format
            },
            compressionRatio: compressionRatio.toFixed(2),
            thumbnail: path.basename(thumbPath)
        };
    } catch (error) {
        console.error('Image processing error:', error);
        throw error;
    }
}

// 2. Extract EXIF Data from Images
async function extractExifData(imagePath) {
    try {
        const metadata = await sharp(imagePath).metadata();
        
        return {
            width: metadata.width,
            height: metadata.height,
            format: metadata.format,
            hasAlpha: metadata.hasAlpha,
            density: metadata.density,
            chromaSubsampling: metadata.chromaSubsampling,
            isProgressive: metadata.isProgressive,
            size: fs.statSync(imagePath).size,
            exif: metadata.exif ? 'EXIF data present' : 'No EXIF data',
            orientation: metadata.orientation,
            resolution: {
                x: metadata.resolutionUnit,
                y: metadata.resolutionUnit
            }
        };
    } catch (error) {
        console.error('EXIF extraction error:', error);
        return null;
    }
}

// 3. Validate Image Quality
function validateImageQuality(imagePath) {
    return new Promise((resolve, reject) => {
        sharp(imagePath)
            .metadata()
            .then(metadata => {
                const issues = [];
                
                // Check dimensions
                if (metadata.width < 200 || metadata.height < 200) {
                    issues.push('Image dimensions too small (minimum 200x200 recommended)');
                }
                
                // Check file size (max 5MB)
                const size = fs.statSync(imagePath).size;
                if (size > 5 * 1024 * 1024) {
                    issues.push('Image size exceeds 5MB limit');
                }
                
                // Check format
                if (!['jpeg', 'png', 'webp'].includes(metadata.format)) {
                    issues.push(`Format ${metadata.format} not recommended (use JPEG, PNG, or WEBP)`);
                }
                
                resolve({
                    isValid: issues.length === 0,
                    issues: issues,
                    metadata: metadata
                });
            })
            .catch(error => {
                reject(error);
            });
    });
}

// ========== MIDDLEWARE ==========
app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

const limiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    max: 100,
    message: 'Too many requests, please try again later.'
});
app.use('/api/', limiter);

app.use(express.static(path.join(__dirname, '../Frontend')));
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// ========== FILE UPLOAD - WITH FOLDER CREATION ==========
const uploadDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadDir)) {
    fs.mkdirSync(uploadDir, { recursive: true });
    console.log('✅ Uploads directory created at:', uploadDir);
}

const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, uploadDir);
    },
    filename: (req, file, cb) => {
        const unique = Date.now() + '-' + Math.round(Math.random() * 1E9);
        cb(null, unique + path.extname(file.originalname));
    }
});

const fileFilter = (req, file, cb) => {
    const allowedTypes = /jpeg|jpg|png|gif|webp/;
    const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
    const mimetype = allowedTypes.test(file.mimetype);
    
    if (mimetype && extname) {
        cb(null, true);
    } else {
        cb(new Error('Only image files are allowed!'));
    }
};

const upload = multer({ 
    storage: storage, 
    limits: { fileSize: 5 * 1024 * 1024 },
    fileFilter: fileFilter
});

// ========== AUTH MIDDLEWARE ==========
const verifyToken = (req, res, next) => {
    const token = req.headers['authorization']?.split(' ')[1];
    if (!token) return res.status(401).json({ error: 'Access denied' });
    try {
        const decoded = jwt.verify(token, process.env.JWT_SECRET || 'your_secret_key');
        req.userId = decoded.userId;
        req.userRole = decoded.role;
        next();
    } catch (error) {
        return res.status(401).json({ error: 'Invalid token' });
    }
};

// Helper to get auth from request (used in analytics)
function getAuth(req) {
    const token = req.headers['authorization']?.split(' ')[1];
    if (!token) return { userId: null };
    try {
        const decoded = jwt.verify(token, process.env.JWT_SECRET || 'your_secret_key');
        return { userId: decoded.userId, role: decoded.role };
    } catch {
        return { userId: null };
    }
}

// ========== AUTH ROUTES ==========
app.post('/api/auth/register', async (req, res) => {
    const { fullName, email, password, phone, address, role } = req.body;
    
    console.log('📝 Registration attempt:', { fullName, email, role });
    
    if (!fullName || !email || !password) {
        return res.status(400).json({ error: 'Missing required fields' });
    }
    
    if (password.length < 6) {
        return res.status(400).json({ error: 'Password must be at least 6 characters' });
    }
    
    try {
        db.query('SELECT id FROM users WHERE email = ?', [email], async (err, results) => {
            if (err) {
                console.error('Database error:', err);
                return res.status(500).json({ error: 'Database error' });
            }
            
            if (results.length > 0) {
                return res.status(409).json({ error: 'User already exists with this email' });
            }
            
            const hashedPassword = await bcrypt.hash(password, 10);
            const userRole = role || 'citizen';
            
            const insertQuery = `INSERT INTO users 
                (full_name, email, password, phone, address, account_type, role, points) 
                VALUES (?, ?, ?, ?, ?, ?, ?, 0)`;
            
            db.query(insertQuery, 
                [fullName, email, hashedPassword, phone || null, address || null, userRole, userRole], 
                (err, result) => {
                    if (err) {
                        console.error('Insert error:', err);
                        return res.status(500).json({ error: 'Failed to create user', details: err.message });
                    }
                    
                    const token = jwt.sign(
                        { userId: result.insertId, email, role: userRole },
                        process.env.JWT_SECRET || 'your_secret_key',
                        { expiresIn: '7d' }
                    );
                    
                    console.log('✅ User registered:', { id: result.insertId, email, role: userRole });
                    
                    res.status(201).json({
                        message: 'User registered successfully',
                        token,
                        user: { 
                            id: result.insertId, 
                            fullName, 
                            email, 
                            role: userRole, 
                            points: 0 
                        }
                    });
                }
            );
        });
    } catch (error) {
        console.error('Registration error:', error);
        res.status(500).json({ error: 'Registration failed: ' + error.message });
    }
});

app.post('/api/auth/login', (req, res) => {
    const { email, password } = req.body;
    
    console.log('🔐 Login attempt:', { email });
    
    if (!email || !password) {
        return res.status(400).json({ error: 'Email and password required' });
    }
    
    db.query('SELECT * FROM users WHERE email = ?', [email], async (err, users) => {
        if (err) {
            console.error('Database error:', err);
            return res.status(500).json({ error: 'Database error' });
        }
        
        if (users.length === 0) {
            return res.status(401).json({ error: 'Invalid email or password' });
        }
        
        const user = users[0];
        const validPassword = await bcrypt.compare(password, user.password);
        
        if (!validPassword) {
            return res.status(401).json({ error: 'Invalid email or password' });
        }
        
        if (!user.is_active) {
            return res.status(403).json({ error: 'Account is deactivated. Contact admin.' });
        }
        
        const token = jwt.sign(
            { userId: user.id, email: user.email, role: user.role },
            process.env.JWT_SECRET || 'your_secret_key',
            { expiresIn: '7d' }
        );
        
        console.log('✅ User logged in:', { id: user.id, email: user.email, role: user.role });
        
        res.json({
            message: 'Login successful',
            token,
            user: {
                id: user.id,
                fullName: user.full_name,
                email: user.email,
                role: user.role,
                points: user.points || 0
            }
        });
    });
});

app.get('/api/auth/me', verifyToken, (req, res) => {
    db.query(
        'SELECT id, full_name, email, phone, address, role, points FROM users WHERE id = ?',
        [req.userId],
        (err, users) => {
            if (err || users.length === 0) {
                return res.status(404).json({ error: 'User not found' });
            }
            res.json({ user: users[0] });
        }
    );
});

// ========== REPORT ROUTES ==========
app.get('/api/reports', verifyToken, (req, res) => {
    db.query(
        'SELECT * FROM reports WHERE user_id = ? ORDER BY created_at DESC',
        [req.userId],
        (err, reports) => {
            if (err) return res.status(500).json({ error: err.message });
            res.json({ reports });
        }
    );
});

app.get('/api/reports/:id', verifyToken, (req, res) => {
    db.query(
        'SELECT * FROM reports WHERE id = ? AND user_id = ?',
        [req.params.id, req.userId],
        (err, reports) => {
            if (err || reports.length === 0) {
                return res.status(404).json({ error: 'Report not found' });
            }
            res.json({ report: reports[0] });
        }
    );
});

// Enhanced report creation with NLP AND IMAGE PROCESSING
app.post('/api/reports', verifyToken, upload.single('image'), async (req, res) => {
    console.log('📝 Report submission received with NLP & Image Processing');
    console.log('Request body:', req.body);
    console.log('File:', req.file);
    
    try {
        const { citizen_name, email, phone, title, description, location_address, location_lat, location_lng, is_anonymous } = req.body;
        const reference = generateReference();
        let image_path = null;
        let imageInfo = null;
        
        // ===== IMAGE PROCESSING =====
        let processedImagePath = null;
        let exifData = null;
        
        if (req.file) {
            try {
                // Validate image quality
                const validation = await validateImageQuality(req.file.path);
                if (!validation.isValid) {
                    console.warn('Image quality issues:', validation.issues);
                }
                
                // Process and compress image
                const processedFilename = `processed_${Date.now()}_${req.file.filename}`;
                const processedPath = path.join(uploadDir, processedFilename);
                
                imageInfo = await processImage(req.file.path, processedPath, {
                    width: 800,
                    height: 800,
                    quality: 80
                });
                
                // Extract EXIF data
                exifData = await extractExifData(req.file.path);
                if (exifData) {
                    console.log('📷 EXIF Data:', exifData);
                }
                
                // Delete original file
                fs.unlinkSync(req.file.path);
                
                image_path = processedFilename;
                
                console.log('✅ Image processed successfully:', {
                    original: imageInfo.original.size,
                    processed: imageInfo.processed.size,
                    compression: imageInfo.compressionRatio + '%'
                });
                
            } catch (error) {
                console.error('Image processing error:', error);
                // Fallback to original image
                image_path = req.file.filename;
                console.log('⚠️ Using original image as fallback');
            }
        }
        
        // ===== VALIDATION =====
        if (!citizen_name || !title || !description) {
            return res.status(400).json({ error: 'Missing required fields: name, title, and description are required' });
        }
        
        // ===== ENHANCED NLP =====
        const categoryResult = enhancedAutoCategorize(description, title);
        const finalCategory = categoryResult.category;
        const categoryConfidence = categoryResult.confidence;
        
        const sentiment = analyzeSentiment(description);
        const urgencyScore = sentiment.urgencyScore;
        const summary = generateSummary(description, 120);
        
        let priority = 'medium';
        if (urgencyScore >= 4) priority = 'emergency';
        else if (urgencyScore === 3) priority = 'high';
        else if (urgencyScore === 2) priority = 'medium';
        else priority = 'low';
        
        const displayName = (is_anonymous === 'true' || is_anonymous === true) ? 'Anonymous Citizen' : citizen_name;
        const lat = location_lat ? parseFloat(location_lat) : null;
        const lng = location_lng ? parseFloat(location_lng) : null;
        const anonymousFlag = (is_anonymous === 'true' || is_anonymous === true) ? 1 : 0;
        
        const qrCode = await generateQRCode(reference);
        
        const query = `INSERT INTO reports 
            (reference, user_id, citizen_name, email, phone, title, description, category, priority, 
             location_address, location_lat, location_lng, image_path, qr_code, is_anonymous, urgency_score)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`;
        
        db.query(query, 
            [reference, req.userId, displayName, email || null, phone || null, title, description, 
             finalCategory, priority, location_address || null, lat, lng, image_path, qrCode, anonymousFlag, urgencyScore],
            (err, result) => {
                if (err) {
                    console.error('Database error:', err);
                    return res.status(500).json({ error: 'Failed to submit report: ' + err.message });
                }
                
                db.query('UPDATE users SET points = points + 10 WHERE id = ?', [req.userId]);
                
                console.log('✅ Report submitted successfully:', reference);
                
                const responseData = {
                    message: 'Report submitted successfully',
                    reference,
                    id: result.insertId,
                    category: finalCategory,
                    categoryConfidence: categoryConfidence,
                    priority,
                    urgencyScore,
                    sentiment: sentiment.sentiment,
                    summary,
                    qrCode
                };
                
                // Add image info if available
                if (imageInfo) {
                    responseData.image = {
                        processed: imageInfo.processed,
                        compressionRatio: imageInfo.compressionRatio,
                        thumbnail: imageInfo.thumbnail
                    };
                }
                
                res.status(201).json(responseData);
            });
    } catch (error) {
        console.error('Server error:', error);
        res.status(500).json({ error: 'Server error: ' + error.message });
    }
});

app.put('/api/reports/:id/status', verifyToken, (req, res) => {
    const { status } = req.body;
    
    db.query(
        'UPDATE reports SET status = ?, updated_at = NOW() WHERE id = ? AND user_id = ?',
        [status, req.params.id, req.userId],
        (err, result) => {
            if (err) return res.status(500).json({ error: err.message });
            if (result.affectedRows === 0) return res.status(404).json({ error: 'Report not found' });
            
            if (status === 'resolved') {
                db.query('UPDATE users SET points = points + 20 WHERE id = ?', [req.userId]);
            }
            res.json({ message: 'Status updated' });
        }
    );
});

app.delete('/api/reports/:id', verifyToken, (req, res) => {
    db.query('DELETE FROM reports WHERE id = ? AND user_id = ?', [req.params.id, req.userId], (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        if (result.affectedRows === 0) return res.status(404).json({ error: 'Report not found' });
        res.json({ message: 'Report deleted' });
    });
});

// ========== PUBLIC ROUTES ==========
app.get('/api/public/report/:reference', (req, res) => {
    const { reference } = req.params;
    db.query(
        'SELECT reference, title, description, category, status, priority, location_address, created_at, updated_at FROM reports WHERE reference = ?',
        [reference],
        (err, reports) => {
            if (err || reports.length === 0) return res.status(404).json({ error: 'Report not found' });
            res.json({ report: reports[0] });
        }
    );
});

app.get('/api/map/reports', (req, res) => {
    db.query(
        'SELECT id, reference, title, description, category, status, priority, location_lat, location_lng, location_address, created_at FROM reports WHERE location_lat IS NOT NULL AND location_lng IS NOT NULL ORDER BY created_at DESC LIMIT 100',
        (err, reports) => {
            if (err) return res.status(500).json({ error: err.message });
            res.json({ reports });
        }
    );
});

app.get('/api/leaderboard', (req, res) => {
    db.query(
        'SELECT full_name, points FROM users WHERE role = "citizen" ORDER BY points DESC LIMIT 10',
        (err, users) => {
            if (err) return res.status(500).json({ error: err.message });
            res.json({ leaderboard: users });
        }
    );
});

app.get('/api/stats', (req, res) => {
    db.query('SELECT COUNT(*) as total FROM reports', (err, total) => {
        db.query('SELECT COUNT(*) as resolved FROM reports WHERE status = "resolved"', (err, resolved) => {
            db.query('SELECT COUNT(*) as pending FROM reports WHERE status = "pending"', (err, pending) => {
                res.json({
                    totalReports: total[0]?.total || 0,
                    resolvedReports: resolved[0]?.resolved || 0,
                    pendingReports: pending[0]?.pending || 0
                });
            });
        });
    });
});

// ========== ADMIN ROUTES ==========
app.get('/api/admin/stats', verifyToken, (req, res) => {
    if (req.userRole !== 'admin') return res.status(403).json({ error: 'Admin access required' });
    
    db.query('SELECT COUNT(*) as totalReports FROM reports', (err, total) => {
        db.query('SELECT COUNT(*) as pending FROM reports WHERE status = "pending"', (err, pending) => {
            db.query('SELECT COUNT(*) as inProgress FROM reports WHERE status = "in_progress"', (err, progress) => {
                db.query('SELECT COUNT(*) as resolved FROM reports WHERE status = "resolved"', (err, resolved) => {
                    db.query('SELECT COUNT(*) as totalUsers FROM users', (err, users) => {
                        db.query('SELECT category, COUNT(*) as count FROM reports GROUP BY category', (err, categories) => {
                            res.json({
                                totalReports: total[0]?.totalReports || 0,
                                pending: pending[0]?.pending || 0,
                                inProgress: progress[0]?.inProgress || 0,
                                resolved: resolved[0]?.resolved || 0,
                                totalUsers: users[0]?.totalUsers || 0,
                                categories: categories || []
                            });
                        });
                    });
                });
            });
        });
    });
});

app.get('/api/admin/reports', verifyToken, (req, res) => {
    if (req.userRole !== 'admin') return res.status(403).json({ error: 'Admin access required' });
    
    db.query(
        `SELECT r.*, u.full_name as reporter_name 
         FROM reports r 
         JOIN users u ON r.user_id = u.id 
         ORDER BY r.created_at DESC`,
        (err, reports) => {
            if (err) return res.status(500).json({ error: err.message });
            res.json({ reports });
        }
    );
});

app.put('/api/admin/reports/:id', verifyToken, (req, res) => {
    if (req.userRole !== 'admin') return res.status(403).json({ error: 'Admin access required' });
    
    const { status, priority, admin_notes } = req.body;
    const updates = [];
    const values = [];
    
    if (status) { updates.push('status = ?'); values.push(status); }
    if (priority) { updates.push('priority = ?'); values.push(priority); }
    if (admin_notes !== undefined) { updates.push('admin_notes = ?'); values.push(admin_notes); }
    
    if (updates.length === 0) return res.status(400).json({ error: 'No updates provided' });
    
    updates.push('updated_at = NOW()');
    values.push(req.params.id);
    
    db.query(`UPDATE reports SET ${updates.join(', ')} WHERE id = ?`, values, (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        if (result.affectedRows === 0) return res.status(404).json({ error: 'Report not found' });
        res.json({ message: 'Report updated' });
    });
});

// ========== ANALYTICS ROUTES ==========

// 1. Report Trends Analysis
app.get('/api/analytics/trends', verifyToken, (req, res) => {
    const auth = getAuth(req);
    const userId = auth.userId;
    
    db.query(`
        SELECT 
            DATE(created_at) as date,
            COUNT(*) as total,
            SUM(CASE WHEN status = 'resolved' THEN 1 ELSE 0 END) as resolved,
            SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending,
            SUM(CASE WHEN status = 'in_progress' THEN 1 ELSE 0 END) as in_progress
        FROM reports
        WHERE user_id = ?
        GROUP BY DATE(created_at)
        ORDER BY DATE(created_at) DESC
        LIMIT 30
    `, [userId], (err, trends) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ trends });
    });
});

// 2. Hotspot Detection - Find areas with most reports
app.get('/api/analytics/hotspots', (req, res) => {
    db.query(`
        SELECT 
            location_address,
            COUNT(*) as report_count,
            AVG(urgency_score) as avg_urgency,
            GROUP_CONCAT(DISTINCT category) as categories,
            MAX(location_lat) as lat,
            MAX(location_lng) as lng
        FROM reports
        WHERE location_address IS NOT NULL 
        AND location_address != ''
        GROUP BY location_address
        HAVING COUNT(*) > 1
        ORDER BY COUNT(*) DESC
        LIMIT 20
    `, (err, hotspots) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ hotspots });
    });
});

// 3. Resolution Time Prediction - Average resolution time by category
app.get('/api/analytics/resolution-time', verifyToken, (req, res) => {
    db.query(`
        SELECT 
            category,
            AVG(TIMESTAMPDIFF(HOUR, created_at, updated_at)) as avg_hours,
            MIN(TIMESTAMPDIFF(HOUR, created_at, updated_at)) as min_hours,
            MAX(TIMESTAMPDIFF(HOUR, created_at, updated_at)) as max_hours,
            COUNT(*) as total_resolved
        FROM reports
        WHERE status = 'resolved'
        GROUP BY category
        ORDER BY avg_hours ASC
    `, (err, predictions) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ predictions });
    });
});

// 4. NLP: Find Similar Reports
app.post('/api/analytics/similar-reports', verifyToken, (req, res) => {
    const { description } = req.body;
    const auth = getAuth(req);
    const userId = auth.userId;
    
    db.query(
        'SELECT title, description FROM reports WHERE user_id = ?',
        [userId],
        (err, reports) => {
            if (err) return res.status(500).json({ error: err.message });
            
            const existingDescriptions = reports.map(r => r.title + ' ' + r.description);
            const similar = findSimilarReports(description, existingDescriptions);
            
            res.json({ similar });
        }
    );
});

// ========== IMAGE PROCESSING ROUTES ==========

// Get image with processing options (resize on the fly)
app.get('/api/images/:filename', (req, res) => {
    const { filename } = req.params;
    const { width, height, quality } = req.query;
    const imagePath = path.join(__dirname, 'uploads', filename);
    
    if (!fs.existsSync(imagePath)) {
        return res.status(404).json({ error: 'Image not found' });
    }
    
    // If size parameters provided, serve resized version
    if (width || height) {
        const options = {};
        if (width) options.width = parseInt(width);
        if (height) options.height = parseInt(height);
        if (quality) options.quality = parseInt(quality);
        
        sharp(imagePath)
            .resize(options)
            .jpeg({ quality: options.quality || 80 })
            .pipe(res);
    } else {
        res.sendFile(imagePath);
    }
});

// Get image metadata (EXIF data)
app.get('/api/images/:filename/metadata', (req, res) => {
    const { filename } = req.params;
    const imagePath = path.join(__dirname, 'uploads', filename);
    
    if (!fs.existsSync(imagePath)) {
        return res.status(404).json({ error: 'Image not found' });
    }
    
    extractExifData(imagePath)
        .then(metadata => {
            res.json({ metadata });
        })
        .catch(error => {
            res.status(500).json({ error: 'Failed to extract metadata' });
        });
});

// Get image thumbnail
app.get('/api/images/:filename/thumbnail', (req, res) => {
    const { filename } = req.params;
    const thumbPath = path.join(__dirname, 'uploads', filename.replace(/\.[^.]+$/, '_thumb.jpg'));
    
    if (!fs.existsSync(thumbPath)) {
        // Generate thumbnail on the fly if not exists
        const imagePath = path.join(__dirname, 'uploads', filename);
        if (!fs.existsSync(imagePath)) {
            return res.status(404).json({ error: 'Image not found' });
        }
        
        sharp(imagePath)
            .resize(150, 150, { fit: 'cover' })
            .jpeg({ quality: 60 })
            .pipe(res);
    } else {
        res.sendFile(thumbPath);
    }
});

// ========== FRONTEND ROUTES ==========
app.get('/', (req, res) => res.sendFile(path.join(__dirname, '../Frontend/index.html')));
app.get('/index', (req, res) => res.sendFile(path.join(__dirname, '../Frontend/index.html')));
app.get('/index.html', (req, res) => res.sendFile(path.join(__dirname, '../Frontend/index.html')));
app.get('/register', (req, res) => res.sendFile(path.join(__dirname, '../Frontend/register.html')));
app.get('/login', (req, res) => res.sendFile(path.join(__dirname, '../Frontend/login.html')));
app.get('/dashboard', (req, res) => res.sendFile(path.join(__dirname, '../Frontend/dashboard.html')));
app.get('/admin', (req, res) => res.sendFile(path.join(__dirname, '../Frontend/admin.html')));
app.get('/admin-reports', (req, res) => res.sendFile(path.join(__dirname, '../Frontend/admin-reports.html')));
app.get('/map', (req, res) => res.sendFile(path.join(__dirname, '../Frontend/map.html')));
app.get('/track', (req, res) => res.sendFile(path.join(__dirname, '../Frontend/track.html')));
app.get('/track/:reference', (req, res) => res.sendFile(path.join(__dirname, '../Frontend/track.html')));

// ========== START SERVER ==========
app.listen(PORT, () => {
    console.log(`\n🚀 CivicConnect Server Running`);
    console.log(`📍 URL: http://localhost:${PORT}`);
    console.log(`📁 Uploads directory: ${uploadDir}`);
    console.log(`\n✨ Features Enabled:`);
    console.log(`   🤖 Auto-Categorization`);
    console.log(`   🎯 Auto-Priority Detection`);
    console.log(`   🔒 Anonymous Reporting`);
    console.log(`   📱 QR Code Generation`);
    console.log(`   🗺️ Interactive Map Support`);
    console.log(`   🏆 Gamification & Points`);
    console.log(`   🧠 NLP Sentiment Analysis`);
    console.log(`   📊 Analytics & Trends`);
    console.log(`   🔥 Hotspot Detection`);
    console.log(`   🖼️ Image Processing & Compression`);
    console.log(`   📷 EXIF Data Extraction`);
    console.log(`   🔍 On-the-fly Image Resizing`);
    console.log(`\n🔐 Default Admin Account:`);
    console.log(`   Email: admin@civicconnect.com`);
    console.log(`   Password: admin123`);
    console.log(`\n📝 Available Routes:`);
    console.log(`   http://localhost:${PORT}/`);
    console.log(`   http://localhost:${PORT}/register`);
    console.log(`   http://localhost:${PORT}/login`);
    console.log(`   http://localhost:${PORT}/dashboard`);
    console.log(`   http://localhost:${PORT}/admin`);
    console.log(`   http://localhost:${PORT}/admin-reports`);
    console.log(`   http://localhost:${PORT}/map`);
    console.log(`   http://localhost:${PORT}/track`);
    console.log(`   http://localhost:${PORT}/api/images/:filename (Image resizing)`);
    console.log(`   http://localhost:${PORT}/api/images/:filename/metadata (EXIF data)\n`);
});