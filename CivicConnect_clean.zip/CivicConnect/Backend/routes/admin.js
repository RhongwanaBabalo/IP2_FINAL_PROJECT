const express = require('express');
const { pool } = require('../db');
const { verifyToken } = require('./auth');

const router = express.Router();

// Middleware to check admin role
const isAdmin = async (req, res, next) => {
    try {
        const [users] = await pool.query('SELECT role FROM users WHERE id = ?', [req.userId]);
        if (users.length === 0 || users[0].role !== 'admin') {
            return res.status(403).json({ error: 'Admin access required' });
        }
        next();
    } catch (error) {
        res.status(500).json({ error: 'Authorization error' });
    }
};

// Get all reports (admin)
router.get('/reports', verifyToken, isAdmin, async (req, res) => {
    try {
        const [reports] = await pool.query(
            `SELECT r.*, u.full_name as reporter_name, u.email as reporter_email
             FROM reports r
             JOIN users u ON r.user_id = u.id
             ORDER BY 
               CASE r.status 
                 WHEN 'pending' THEN 1 
                 WHEN 'in_progress' THEN 2 
                 WHEN 'resolved' THEN 3 
                 ELSE 4 
               END,
               r.priority DESC,
               r.created_at DESC`
        );
        
        res.json({ reports });
    } catch (error) {
        res.status(500).json({ error: 'Failed to fetch reports' });
    }
});

// Get dashboard statistics
router.get('/stats', verifyToken, isAdmin, async (req, res) => {
    try {
        const [totalReports] = await pool.query('SELECT COUNT(*) as count FROM reports');
        const [pendingReports] = await pool.query('SELECT COUNT(*) as count FROM reports WHERE status = "pending"');
        const [inProgressReports] = await pool.query('SELECT COUNT(*) as count FROM reports WHERE status = "in_progress"');
        const [resolvedReports] = await pool.query('SELECT COUNT(*) as count FROM reports WHERE status = "resolved"');
        const [totalUsers] = await pool.query('SELECT COUNT(*) as count FROM users WHERE role = "citizen"');
        
        const [categoryStats] = await pool.query(
            'SELECT category, COUNT(*) as count FROM reports GROUP BY category'
        );
        
        res.json({
            totalReports: totalReports[0].count,
            pending: pendingReports[0].count,
            inProgress: inProgressReports[0].count,
            resolved: resolvedReports[0].count,
            totalUsers: totalUsers[0].count,
            categories: categoryStats
        });
    } catch (error) {
        res.status(500).json({ error: 'Failed to fetch stats' });
    }
});

// Update report (admin)
router.put('/reports/:id', verifyToken, isAdmin, async (req, res) => {
    const { id } = req.params;
    const { status, admin_notes, priority } = req.body;
    
    try {
        const [reports] = await pool.query('SELECT status FROM reports WHERE id = ?', [id]);
        if (reports.length === 0) {
            return res.status(404).json({ error: 'Report not found' });
        }
        
        const oldStatus = reports[0].status;
        
        await pool.query(
            'UPDATE reports SET status = ?, admin_notes = ?, priority = ?, updated_at = NOW() WHERE id = ?',
            [status || oldStatus, admin_notes || null, priority || 'medium', id]
        );
        
        if (status && status !== oldStatus) {
            await pool.query(
                'INSERT INTO status_history (report_id, old_status, new_status, changed_by, notes) VALUES (?, ?, ?, ?, ?)',
                [id, oldStatus, status, req.userId, admin_notes || null]
            );
        }
        
        res.json({ message: 'Report updated successfully' });
    } catch (error) {
        res.status(500).json({ error: 'Failed to update report' });
    }
});

// Get all users (admin)
router.get('/users', verifyToken, isAdmin, async (req, res) => {
    try {
        const [users] = await pool.query(
            'SELECT id, full_name, email, phone, role, is_active, created_at FROM users ORDER BY created_at DESC'
        );
        res.json({ users });
    } catch (error) {
        res.status(500).json({ error: 'Failed to fetch users' });
    }
});

module.exports = router;