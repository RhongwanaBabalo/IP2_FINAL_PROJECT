const express = require('express');
const multer = require('multer');
const path = require('path');
const { body, validationResult } = require('express-validator');
const { pool } = require('../db');
const { verifyToken } = require('./auth');

const router = express.Router();

// Configure multer for file uploads
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, path.join(__dirname, '../uploads'));
    },
    filename: (req, file, cb) => {
        const unique = Date.now() + '-' + Math.round(Math.random() * 1E9);
        cb(null, unique + path.extname(file.originalname));
    }
});

const upload = multer({ 
    storage,
    limits: { fileSize: 5 * 1024 * 1024 }, // 5MB limit
    fileFilter: (req, file, cb) => {
        const allowed = /jpeg|jpg|png|gif/;
        const ext = allowed.test(path.extname(file.originalname).toLowerCase());
        const mime = allowed.test(file.mimetype);
        if (ext && mime) cb(null, true);
        else cb(new Error('Only images are allowed'));
    }
});

// Generate unique reference number
function generateReference() {
    const year = new Date().getFullYear();
    const random = Math.floor(Math.random() * 10000);
    return `CRC-${year}-${random}`;
}

// Get all reports for logged-in user
router.get('/', verifyToken, async (req, res) => {
    try {
        const [reports] = await pool.query(
            `SELECT r.*, 
             (SELECT COUNT(*) FROM status_history WHERE report_id = r.id) as status_updates
             FROM reports r 
             WHERE r.user_id = ? 
             ORDER BY r.created_at DESC`,
            [req.userId]
        );
        
        res.json({ reports });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Failed to fetch reports' });
    }
});

// Get single report
router.get('/:id', verifyToken, async (req, res) => {
    try {
        const [reports] = await pool.query(
            'SELECT * FROM reports WHERE id = ? AND user_id = ?',
            [req.params.id, req.userId]
        );
        
        if (reports.length === 0) {
            return res.status(404).json({ error: 'Report not found' });
        }
        
        // Increment view count
        await pool.query('UPDATE reports SET views = views + 1 WHERE id = ?', [req.params.id]);
        
        // Get status history
        const [history] = await pool.query(
            `SELECT sh.*, u.full_name as changed_by_name 
             FROM status_history sh
             LEFT JOIN users u ON sh.changed_by = u.id
             WHERE sh.report_id = ?
             ORDER BY sh.changed_at DESC`,
            [req.params.id]
        );
        
        res.json({ report: reports[0], history });
    } catch (error) {
        res.status(500).json({ error: 'Failed to fetch report' });
    }
});

// Create new report
router.post('/', verifyToken, upload.single('image'), [
    body('citizen_name').trim().notEmpty(),
    body('title').trim().notEmpty(),
    body('description').trim().isLength({ min: 10 }),
    body('category').isIn(['roads', 'water', 'electricity', 'sanitation', 'safety', 'other']),
    body('location_address').optional().trim(),
    body('priority').optional().isIn(['low', 'medium', 'high', 'emergency'])
], async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
    }
    
    const { citizen_name, email, phone, title, description, category, location_address, priority } = req.body;
    const image_path = req.file ? req.file.filename : null;
    const reference = generateReference();
    
    try {
        const [result] = await pool.query(
            `INSERT INTO reports 
             (reference, user_id, citizen_name, email, phone, title, description, category, location_address, image_path, priority)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [reference, req.userId, citizen_name, email || null, phone || null, title, description, category, location_address || null, image_path, priority || 'medium']
        );
        
        // Add initial status history
        await pool.query(
            'INSERT INTO status_history (report_id, old_status, new_status, changed_by) VALUES (?, ?, ?, ?)',
            [result.insertId, null, 'pending', req.userId]
        );
        
        res.status(201).json({
            message: 'Report submitted successfully',
            reference: reference,
            id: result.insertId
        });
        
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Failed to submit report' });
    }
});

// Update report status
router.put('/:id/status', verifyToken, [
    body('status').isIn(['pending', 'in_progress', 'resolved', 'rejected']),
    body('notes').optional().trim()
], async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
    }
    
    const { id } = req.params;
    const { status, notes } = req.body;
    
    try {
        // Get current status
        const [reports] = await pool.query('SELECT status FROM reports WHERE id = ?', [id]);
        if (reports.length === 0) {
            return res.status(404).json({ error: 'Report not found' });
        }
        
        const oldStatus = reports[0].status;
        
        // Update report status
        await pool.query(
            'UPDATE reports SET status = ?, updated_at = NOW() WHERE id = ?',
            [status, id]
        );
        
        // Add to history
        await pool.query(
            'INSERT INTO status_history (report_id, old_status, new_status, changed_by, notes) VALUES (?, ?, ?, ?, ?)',
            [id, oldStatus, status, req.userId, notes || null]
        );
        
        res.json({ message: 'Status updated successfully' });
        
    } catch (error) {
        res.status(500).json({ error: 'Failed to update status' });
    }
});

// Delete report
router.delete('/:id', verifyToken, async (req, res) => {
    try {
        const [result] = await pool.query(
            'DELETE FROM reports WHERE id = ? AND user_id = ?',
            [req.params.id, req.userId]
        );
        
        if (result.affectedRows === 0) {
            return res.status(404).json({ error: 'Report not found' });
        }
        
        res.json({ message: 'Report deleted successfully' });
    } catch (error) {
        res.status(500).json({ error: 'Failed to delete report' });
    }
});

module.exports = router;